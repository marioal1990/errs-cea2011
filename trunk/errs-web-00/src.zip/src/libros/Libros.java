package libros;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Libros")
public class Libros extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		PrintWriter writer = response.getWriter();
		writer.println("<html>" + "<body>" + "<h1>LISTADO DE LIBROS</h1>");

		Connection conexion;
		Statement s;
		ResultSet rs;
		try {

			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection(
					"jdbc:mysql://localhost/libreria", "root", "root");
			s = conexion.createStatement();
			rs = s.executeQuery("select * from libros");
			while (rs.next()) {
				
				writer.println(rs.getString("titulo")+" <a href = './LibroDetail?id=1'>[detalle]</a>");
				writer.println(" <a href = './LibroEdit?id=1'>[editar]</a>"+"<br>");
			}
			conexion.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		writer.println("</body>" + "</html>");

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

}
